#ifndef		SERVER_HH
# define	SERVER_HH

# include	"LobbyManager.hh"

class		Server
{
private:
  LobbyManager	_lobbyManager;
  ISocket	*_sock;
  
public:
  Server();
  ~Server();

  LobbyManager&	getLobbyManager();
  ISocket*	getSock() const;

  void		addClient(Client *);

  void		setLobbyManager(LobbyManager &);
  void		setSock(ISocket *);
};

#endif
