#ifndef		CLIENT_HH
# define	CLIENT_HH

# include	"ISocket.hpp"

class		Client
{
private:
  ISocket	*_sock;
  std::string	_sendBuffer;
  std::string	_recvBuffer;

public:
  Client(ISocket *sock);
  ~Client();
  ISocket*	getSock() const;
  std::string	getSendBuffer() const;
  std::string	getRecvBuffer() const;

  void		setSock(ISocket *);
  void		setSendBuffer(const std::string &);
  void		setRecvBuffer(const std::string &);
};

#endif
