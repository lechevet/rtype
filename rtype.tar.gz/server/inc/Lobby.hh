#ifndef		LOBBY_HH
# define	LOBBY_HH

# include	"ClientManager.hh"
class		Lobby
{
private:
  ClientManager	_clientManager;
  int		_activeClients;

  void		numberClients();

public:
  Lobby();
  ~Lobby();
  ClientManager&	getClientManager();
  void			addClient(Client *);
  int			getNumberClients() const;
};

#endif
