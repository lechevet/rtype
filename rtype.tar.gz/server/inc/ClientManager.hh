#ifndef		CLIENTMANAGER_HH
# define	CLIENTMANAGER_HH

# include	<list>
# include	"Client.hh"

class		ClientManager
{
private:
  std::list<Client * >	_list;

public:
  ClientManager();
  ~ClientManager();
  void		add(Client *);
  void		remove(Client *);
  Client*	get(int);
  void		remove_all();
};

#endif
