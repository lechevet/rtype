#include	<iostream>
#include	"ISocket.hpp"
#include	"Socket.hh"
#include	"Client.hh"
#include	"Server.hh"

int main()
{
  Server	server;
  ISocket*	sock;

  server.addClient(new Client(sock));
  server.addClient(new Client(sock));
  server.addClient(new Client(sock));
  server.addClient(new Client(sock));
  server.addClient(new Client(sock));
  std::cout << server.getLobbyManager().count() << std::endl;
  server.getLobbyManager().remove_all();
  return (0);
}
