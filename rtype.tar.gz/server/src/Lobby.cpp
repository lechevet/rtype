#include	"Lobby.hh"

Lobby::Lobby()
{
  _activeClients = 0;
}

Lobby::~Lobby()
{
}

ClientManager&	Lobby::getClientManager()
{
  return (_clientManager);
}

void		Lobby::addClient(Client *client)
{
  numberClients();
  if (_activeClients < 4)
    _clientManager.add(client);
}

void		Lobby::numberClients()
{
  int		i = 0;

  while (_clientManager.get(i) != NULL)
    ++i;
  _activeClients = i;
}

int		Lobby::getNumberClients() const
{
  return (_activeClients);
}
