#include	"Client.hh"

Client::Client(ISocket *sock)
{
  _sock = sock;
}

Client::~Client()
{
}

ISocket*	Client::getSock() const
{
  return (_sock);
}

std::string	Client::getSendBuffer() const
{
  return (_sendBuffer);
}

std::string	Client::getRecvBuffer() const
{
  return (_recvBuffer);
}

void		Client::setSock(ISocket *sock)
{
  _sock = sock;
}

void		Client::setSendBuffer(const std::string &buffer)
{
  _sendBuffer = buffer;
}

void		Client::setRecvBuffer(const std::string &buffer)
{
  _recvBuffer = buffer;
}
