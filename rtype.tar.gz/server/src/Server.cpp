#include	"Server.hh"

Server::Server()
{
}

Server::~Server()
{
}

LobbyManager&	Server::getLobbyManager()
{
  return (_lobbyManager);
}

ISocket*	Server::getSock() const
{
  return (_sock);
}

void		Server::setLobbyManager(LobbyManager &lobbyManager)
{
  _lobbyManager = lobbyManager;
}

void		Server::setSock(ISocket *sock)
{
  _sock = sock;
}

void		Server::addClient(Client *client)
{
  _lobbyManager.addClient(client);
}
