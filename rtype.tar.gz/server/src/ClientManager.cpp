#include	"ClientManager.hh"
#include <iostream>

ClientManager::ClientManager()
{
}

ClientManager::~ClientManager()
{
}

void		ClientManager::add(Client *client)
{
  _list.push_back(client);
}

void		ClientManager::remove(Client *client)
{
  std::list<Client *>::iterator it;

  it = _list.begin();
  while (it != _list.end() && *it != client)
    ++it;
  if (it != _list.end())
    _list.erase(it);
}

Client*		ClientManager::get(int nb)
{
  std::list<Client *>::iterator it;
  int		i = 0;

  it = _list.begin();
  std::cout << _list.size() << std::endl;
  while (it != _list.end() && i < nb + 1)
    {
      ++it;
      ++i;
    }
  if (it != _list.end())
    return (*it);
  return (NULL);
}

void		ClientManager::remove_all()
{
  std::list<Client *>::iterator it;

  it = _list.begin();
  while (it != _list.end())
    it = _list.erase(it);
}
